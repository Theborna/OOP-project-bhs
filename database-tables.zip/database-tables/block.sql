CREATE TABLE `electron`.`block` (
  `user_id` BIGINT(32) NOT NULL,
  `blocked_id` BIGINT(32) NOT NULL);
