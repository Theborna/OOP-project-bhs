CREATE TABLE `electron`.`media` (
  `id` BIGINT(32) NOT NULL,
  `path` LONGTEXT NOT NULL,
  `type` TINYINT(4) NOT NULL,
  PRIMARY KEY (`id`));
