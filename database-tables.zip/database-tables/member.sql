CREATE TABLE `electron`.`member` (
  `userid` BIGINT(32) NOT NULL,
  `chatid` BIGINT(32) NOT NULL,
  `perm` TINYINT(4) NOT NULL);
