CREATE TABLE `electron`.`views` (
  `post_id` BIGINT(32) NOT NULL,
  `user_id` BIGINT(32) NOT NULL,
  `val` TINYINT NOT NULL,
  `view_date` DATETIME NOT NULL,
  `like_date` DATETIME NULL DEFAULT NULL);
