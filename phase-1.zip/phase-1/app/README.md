# phase 1:

inshallah we will write this

> good project with good hadafs