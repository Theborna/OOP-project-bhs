package com.project;

import com.project.controllers.Controller;

public class InputProcessor {

    public static void parse(String input, Controller controller) {

    }

}
