package com.project.enums;

public enum ChatPermission {
    OWNER, ADMIN, NORMAL, OBSERVER;
}
