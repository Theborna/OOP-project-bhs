package com.project.models.node.post;

import com.project.models.node.user.User;

public class PromotedPost extends Post {

    public PromotedPost(String text, User Sender) {
        super(text, Sender);
        //TODO Auto-generated constructor stub
    }

}
