package com.project.enums;

public enum MediaType {
    Image, Video
}
