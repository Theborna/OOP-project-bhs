package com.project.models.node;

public interface TextBased {
    public String getText();

    public StringBuilder getBuilder();

}
