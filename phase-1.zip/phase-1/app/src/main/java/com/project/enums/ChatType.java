package com.project.enums;

public enum ChatType {
    PRIVATE, GROUP, CHANNEL;
}
